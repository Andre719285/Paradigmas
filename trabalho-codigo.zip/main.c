/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MAX_STATIC_SIZE 50
#define MIN_STATIC_SIZE 10

int getMaxStaticSize() {
    time_t t = time(NULL);
    struct tm* currentTime = localtime(&t);
    int hour = currentTime->tm_hour;

    if (hour < 12) {
        return MIN_STATIC_SIZE;
    } else if (hour < 18) {
        return (MIN_STATIC_SIZE + MAX_STATIC_SIZE) / 2;
    } else {
        return MAX_STATIC_SIZE;
    }
}


void searchInMatrix(int** matrix, int rows, int cols, int valor) {
    int found = 0;
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            if (matrix[i][j] == valor) {
                printf("Valor %d encontrado na posição [%d][%d].\n", valor, i, j);
                found = 1;
            }
        }
    }
    if (!found) {
        printf("Valor %d não encontrado.\n", valor);
    }
}


void staticMode() {
    int maxSize = getMaxStaticSize();

    printf("Modo Estático: O limite de elementos é %d\n", maxSize);
    
    int rows, cols;
    printf("Insira o número de linhas e colunas (total deve ser <= %d): ", maxSize);
    scanf("%d %d", &rows, &cols);

    if (rows * cols > maxSize) {
        printf("Erro: Não é possível processar mais de %d elementos no modo estático.\n", maxSize);
        return;
    }

    int matrix[rows][cols];

   
    printf("Insira os elementos da matriz %dx%d:\n", rows, cols);
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            scanf("%d", &matrix[i][j]);
        }
    }

    
    int produto = 1;
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            produto *= matrix[i][j];
        }
    }
    printf("Produto dos elementos: %d\n", produto);

    
    int valorBuscado;
    printf("Insira o valor que deseja buscar: ");
    scanf("%d", &valorBuscado);
    searchInMatrix((int**)matrix, rows, cols, valorBuscado);
}


void dynamicMode() {
    int rows, cols;

    printf("Modo Dinâmico: Insira o número de linhas e colunas: ");
    scanf("%d %d", &rows, &cols);

   
    int** matrix = (int*) malloc(rows * sizeof(int));
    for (int i = 0; i < rows; i++) {
        matrix[i] = (int*) malloc(cols * sizeof(int));
    }

    if (matrix == NULL) {
        printf("Erro ao alocar memória!\n");
        return;
    }

   
    printf("Insira os elementos da matriz %dx%d:\n", rows, cols);
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            scanf("%d", &matrix[i][j]);
        }
    }

   
    int produto = 1;
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            produto *= matrix[i][j];
        }
    }
    printf("Produto dos elementos: %d\n", produto);

    
    int valorBuscado;
    printf("Insira o valor que deseja buscar: ");
    scanf("%d", &valorBuscado);
    searchInMatrix(matrix, rows, cols, valorBuscado);

   
    printf("Deseja adicionar mais linhas à matriz? (1-Sim, 0-Não): ");
    int resposta;
    scanf("%d", &resposta);

    if (resposta == 1) {
        int novasLinhas;
        printf("Quantas linhas adicionais? ");
        scanf("%d", &novasLinhas);

        matrix = (int*) realloc(matrix, (rows + novasLinhas) * sizeof(int));
        for (int i = rows; i < rows + novasLinhas; i++) {
            matrix[i] = (int*) malloc(cols * sizeof(int));
        }

        if (matrix == NULL) {
            printf("Erro ao realocar memória!\n");
            return;
        }

        printf("Insira os elementos das novas %d linhas:\n", novasLinhas);
        for (int i = rows; i < rows + novasLinhas; i++) {
            for (int j = 0; j < cols; j++) {
                scanf("%d", &matrix[i][j]);
            }
        }

        
        for (int i = rows; i < rows + novasLinhas; i++) {
            for (int j = 0; j < cols; j++) {
                produto *= matrix[i][j];
            }
        }
        printf("Novo produto dos elementos: %d\n", produto);

       
        printf("Insira o valor que deseja buscar: ");
        scanf("%d", &valorBuscado);
        searchInMatrix(matrix, rows + novasLinhas, cols, valorBuscado);
    }

    
    for (int i = 0; i < rows + resposta; i++) {
        free(matrix[i]);
    }
    free(matrix);
}

int main() {
    int modo;
    printf("Escolha o modo de operação:\n");
    printf("1 - Modo Estático\n");
    printf("2 - Modo Dinâmico\n");
    printf("Modo: ");
    scanf("%d", &modo);

    if (modo == 1) {
        staticMode();
    } else if (modo == 2) {
        dynamicMode();
    } else {
        printf("Modo inválido!\n");
    }

    return 0;
}