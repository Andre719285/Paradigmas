/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MAX_STATIC_SIZE 50
#define MIN_STATIC_SIZE 10

int getMaxStaticSize() {
    time_t t = time(NULL);
    struct tm* currentTime = localtime(&t);
    int hour = currentTime->tm_hour;

    if (hour < 12) {
        return MIN_STATIC_SIZE;
    } else if (hour < 18) {
        return (MIN_STATIC_SIZE + MAX_STATIC_SIZE) / 2;
    } else {
        return MAX_STATIC_SIZE;
    }
}

void searchInArray(int* array, int n, int valor) {
    int found = 0;
    for (int i = 0; i < n; i++) {
        if (array[i] == valor) {
            printf("Valor %d encontrado na posição %d.\n", valor, i);
            found = 1;
        }
    }
    if (!found) {
        printf("Valor %d não encontrado.\n", valor);
    }
}

void staticMode() {
    int maxSize = getMaxStaticSize();
    int vetor[maxSize];

    printf("Modo Estático: O limite de elementos é %d\n", maxSize);
    printf("Insira o número de elementos a serem processados: ");

    int n;
    scanf("%d", &n);

    if (n > maxSize) {
        printf("Erro: Não é possível processar mais de %d elementos no modo estático.\n", maxSize);
        return;
    }

    printf("Insira %d elementos:\n", n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &vetor[i]);
    }

      int produto = 1;
    for (int i = 0; i < n; i++) {
        produto *= vetor[i];
    }
    printf("Produto dos elementos: %d\n", produto);

    // Busca de um valor no vetor
    int valorBuscado;
    printf("Insira o valor que deseja buscar: ");
    scanf("%d", &valorBuscado);
    searchInArray(vetor, n, valorBuscado);
}

void dynamicMode() {
    int n;

    printf("Modo Dinâmico: Insira o número de elementos a serem processados: ");
    scanf("%d", &n);

    int* vetor = (int*) malloc(n * sizeof(int));
    if (vetor == NULL) {
        printf("Erro ao alocar memória!\n");
        return;
    }

    printf("Insira %d elementos:\n", n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &vetor[i]);
    }

       int produto = 1;
    for (int i = 0; i < n; i++) {
        produto *= vetor[i];
    }
    printf("Produto dos elementos: %d\n", produto);

       int valorBuscado;
    printf("Insira o valor que deseja buscar: ");
    scanf("%d", &valorBuscado);
    searchInArray(vetor, n, valorBuscado);

      printf("Deseja adicionar mais elementos? (1-Sim, 0-Não): ");
    int resposta;
    scanf("%d", &resposta);

    if (resposta == 1) {
        int novoTamanho;
        printf("Quantos elementos adicionais? ");
        scanf("%d", &novoTamanho);

        vetor = (int*) realloc(vetor, (n + novoTamanho) * sizeof(int));
        if (vetor == NULL) {
            printf("Erro ao realocar memória!\n");
            return;
        }

        printf("Insira os %d novos elementos:\n", novoTamanho);
        for (int i = n; i < n + novoTamanho; i++) {
            scanf("%d", &vetor[i]);
        }

        // Multiplicação dos novos elementos
        for (int i = n; i < n + novoTamanho; i++) {
            produto *= vetor[i];
        }
        printf("Novo produto dos elementos: %d\n", produto);

        // Busca de um valor nos novos elementos (opcionalmente poderia repetir)
        printf("Insira o valor que deseja buscar: ");
        scanf("%d", &valorBuscado);
        searchInArray(vetor, n + novoTamanho, valorBuscado);
    }
    
    free(vetor);
}

int main() {
    int modo;
    printf("Escolha o modo de operação:\n");
    printf("1 - Modo Estático\n");
    printf("2 - Modo Dinâmico\n");
    printf("Modo: ");
    scanf("%d", &modo);

    if (modo == 1) {
        staticMode();
    } else if (modo == 2) {
        dynamicMode();
    } else {
        printf("Modo inválido!\n");
    }

    return 0;
}